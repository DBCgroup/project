#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <valuation.h>
#include <annuity.h>
#include <bonds.h>
#include <rate.h>
#include <ear.h>
#include <calculator1.h>


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_valuation_clicked();

    void on_annuity_clicked();

    void on_bonds_clicked();

    void on_rate_clicked();

    void on_pushButton_clicked();





    void on_pushButton_2_clicked();

private:
    Ui::Widget *ui;
    valuation val;
    annuity ann;
    bonds bon;
    rate r;
    ear EAR;
    calculator1 cal;


};

#endif // WIDGET_H
