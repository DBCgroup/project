#include "annuity1.h"
#include "ui_annuity1.h"

annuity1::annuity1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::annuity1)
{
    ui->setupUi(this);
}

annuity1::~annuity1()
{
    delete ui;
}

void annuity1::on_pushButton_clicked()
{
    QString pmt = ui->pmt1->text();
    QByteArray pmt1 = pmt.toLocal8Bit();
    std::string pmt2= std::string(pmt1);
    double pmt3 =atof(pmt2.c_str());
    QString r = ui->r1->text();
    QByteArray r1 = r.toLocal8Bit();
    std::string r2= std::string(r1);
    double r3 =atof(r2.c_str());
    QString n = ui->n1->text();
    QByteArray n1 = n.toLocal8Bit();
    std::string n2= std::string(n1);
    int n3 =atoi(n2.c_str());

    double a=1+r3;

    for(int i=1; i<n3; i++)
    {
        a=a*(1+r3);
    }

    double result1= (a-1)*pmt3/r3;

    QString Answer="answer:";
    QString answer=QString::number(result1);
    Answer = Answer+answer;
    QMessageBox::information(NULL, "Title", Answer, QMessageBox::Ok);
}
