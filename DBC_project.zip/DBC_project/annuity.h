#ifndef ANNUITY_H
#define ANNUITY_H

#include <QDialog>
#include <annuity1.h>
#include <annuity2.h>
#include <annuity3.h>
#include <annuity4.h>
namespace Ui {
class annuity;
}

class annuity : public QDialog
{
    Q_OBJECT

public:
    explicit annuity(QWidget *parent = nullptr);
    ~annuity();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::annuity *ui;
    annuity1 ann1;
    annuity2 ann2;
    annuity3 ann3;
    annuity4 ann4;

};

#endif // ANNUITY_H
