#ifndef RATE_H
#define RATE_H

#include <QDialog>
#include <rate1.h>
#include <rate2.h>

namespace Ui {
class rate;
}

class rate : public QDialog
{
    Q_OBJECT

public:
    explicit rate(QWidget *parent = nullptr);
    ~rate();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::rate *ui;
    rate1 r1;
    rate2 r2;
};

#endif // RATE_H
