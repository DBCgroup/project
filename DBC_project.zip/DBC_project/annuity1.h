#ifndef ANNUITY1_H
#define ANNUITY1_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class annuity1;
}

class annuity1 : public QDialog
{
    Q_OBJECT

public:
    explicit annuity1(QWidget *parent = nullptr);
    ~annuity1();

private slots:
    void on_pushButton_clicked();

private:
    Ui::annuity1 *ui;
};

#endif // ANNUITY1_H
