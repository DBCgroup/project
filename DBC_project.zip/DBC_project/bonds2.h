#ifndef BONDS2_H
#define BONDS2_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class bonds2;
}

class bonds2 : public QDialog
{
    Q_OBJECT

public:
    explicit bonds2(QWidget *parent = nullptr);
    ~bonds2();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bonds2 *ui;
};

#endif // BONDS2_H
