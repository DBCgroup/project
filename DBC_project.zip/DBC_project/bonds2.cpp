#include "bonds2.h"
#include "ui_bonds2.h"

bonds2::bonds2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::bonds2)
{
    ui->setupUi(this);
}

bonds2::~bonds2()
{
    delete ui;
}

void bonds2::on_pushButton_clicked()
{
    QString p = ui->parvalue2->text();
    QByteArray p1 = p.toLocal8Bit();
    std::string p2= std::string(p1);
    double p3 =atof(p2.c_str());
    QString r = ui->r->text();
    QByteArray r1 = r.toLocal8Bit();
    std::string r2= std::string(r1);
    double r3 =atof(r2.c_str());
    QString t = ui->t->text();
    QByteArray t1 = t.toLocal8Bit();
    std::string t2= std::string(t1);
    int t3 =atoi(t2.c_str());
    QString c = ui->c->text();
    QByteArray c1 = c.toLocal8Bit();
    std::string c2= std::string(c1);
    double c3 =atof(c2.c_str());

    double a=1+r3;

    for(int i=1; i<t3; i++)
    {
        a=a*(1+r3);
    }

    double b=c3/(1+r3);

    for(int j=1; j<t3; j++)
    {
        b=b+b/(1+r3);
    }

    double result1= p3/a+b;

    QString Answer="answer:";
    QString answer=QString::number(result1);
    Answer = Answer+answer;
    QMessageBox::information(NULL, "Title", Answer, QMessageBox::Ok);
}
