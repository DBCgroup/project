#ifndef ANNUITY4_H
#define ANNUITY4_H

#include <QDialog>
#include <QMessageBox>
namespace Ui {
class annuity4;
}

class annuity4 : public QDialog
{
    Q_OBJECT

public:
    explicit annuity4(QWidget *parent = nullptr);
    ~annuity4();

private slots:
    void on_pushButton_clicked();

private:
    Ui::annuity4 *ui;
};

#endif // ANNUITY4_H
