#ifndef ANNUITY3_H
#define ANNUITY3_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class annuity3;
}

class annuity3 : public QDialog
{
    Q_OBJECT

public:
    explicit annuity3(QWidget *parent = nullptr);
    ~annuity3();

private slots:
    void on_pushButton_clicked();

private:
    Ui::annuity3 *ui;
};

#endif // ANNUITY3_H
