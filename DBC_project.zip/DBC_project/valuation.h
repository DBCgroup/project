#ifndef VALUATION_H
#define VALUATION_H

#include <QDialog>
#include <QMessageBox>
namespace Ui {
class valuation;
}

class valuation : public QDialog
{
    Q_OBJECT

public:
    explicit valuation(QWidget *parent = nullptr);
    ~valuation();

private slots:
    void on_pushButton_clicked();

private:
    Ui::valuation *ui;
};

#endif // VALUATION_H
