#ifndef ANNUITY2_H
#define ANNUITY2_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class annuity2;
}

class annuity2 : public QDialog
{
    Q_OBJECT

public:
    explicit annuity2(QWidget *parent = nullptr);
    ~annuity2();

private slots:
    void on_pushButton_clicked();

private:
    Ui::annuity2 *ui;
};

#endif // ANNUITY2_H
