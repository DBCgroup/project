#include "rate2.h"
#include "ui_rate2.h"

rate2::rate2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::rate2)
{
    ui->setupUi(this);
}

rate2::~rate2()
{
    delete ui;
}

void rate2::on_pushButton_clicked()
{
    QString p = ui->p2->text();
    QByteArray p1 = p.toLocal8Bit();
    std::string p2= std::string(p1);
    double p3 =atof(p2.c_str());
    QString r = ui->r2->text();
    QByteArray r1 = r.toLocal8Bit();
    std::string r2= std::string(r1);
    double r3 =atof(r2.c_str());
    QString n = ui->n2->text();
    QByteArray n1 = n.toLocal8Bit();
    std::string n2= std::string(n1);
    int n3 =atoi(n2.c_str());

    double a=1+r3;
    for(int i=1; i<n3; i++ )
    {
        a=a*(1+r3);
    }


    double result1= p3*a;

    QString Answer="answer:";
    QString answer=QString::number(result1);
    Answer = Answer+answer;
    QMessageBox::information(NULL, "Title", Answer, QMessageBox::Ok);
}
