#include "ear.h"
#include "ui_ear.h"

ear::ear(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ear)
{
    ui->setupUi(this);
}

ear::~ear()
{
    delete ui;
}

void ear::on_pushButton_clicked()
{
    QString a = ui->apr->text();
    QByteArray a1 = a.toLocal8Bit();
    std::string a2= std::string(a1);
    double a3 =atof(a2.c_str());
    QString n = ui->time->text();
    QByteArray n1 = n.toLocal8Bit();
    std::string n2= std::string(n1);
    int n3 =atoi(n2.c_str());

    double b=1+a3/n3;

    for(int i=1; i<n3; i++)
    {
        b=b*(1+a3/n3);
    }

    double result1=b-1;

    QString Answer="answer:";
    QString answer=QString::number(result1);
    Answer = Answer+answer;
    QMessageBox::information(NULL, "Title", Answer, QMessageBox::Ok);
}


