#ifndef BONDS_H
#define BONDS_H

#include <QDialog>
#include <bonds1.h>
#include <bonds2.h>

namespace Ui {
class bonds;
}

class bonds : public QDialog
{
    Q_OBJECT

public:
    explicit bonds(QWidget *parent = nullptr);
    ~bonds();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::bonds *ui;
    bonds1 bo1;
    bonds2 bo2;
};

#endif // BONDS_H
