#ifndef BONDS1_H
#define BONDS1_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class bonds1;
}

class bonds1 : public QDialog
{
    Q_OBJECT

public:
    explicit bonds1(QWidget *parent = nullptr);
    ~bonds1();

private slots:
    void on_pushButton_clicked();

private:
    Ui::bonds1 *ui;
};

#endif // BONDS1_H
