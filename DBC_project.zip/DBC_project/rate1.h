#ifndef RATE1_H
#define RATE1_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class rate1;
}

class rate1 : public QDialog
{
    Q_OBJECT

public:
    explicit rate1(QWidget *parent = nullptr);
    ~rate1();

private slots:
    void on_pushButton_clicked();

private:
    Ui::rate1 *ui;
};

#endif // RATE1_H
