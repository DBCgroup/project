#include "calculator1.h"
#include "ui_calculator1.h"

calculator1::calculator1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::calculator1)
{
    ui->setupUi(this);
}

calculator1::~calculator1()
{
    delete ui;
}

void calculator1::on_pushButton_clicked()
{
    calculator.show();
}
