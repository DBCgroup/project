#include "valuation.h"
#include "ui_valuation.h"


valuation::valuation(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::valuation)
{
    ui->setupUi(this);
}

valuation::~valuation()
{
    delete ui;
}

void valuation::on_pushButton_clicked()
{
    QString sa = ui->sales->text();
    QByteArray sa1 = sa.toLocal8Bit();
    std::string sa2= std::string(sa1);
    double sa3 =atof(sa2.c_str());
    QString ea = ui->earnings->text();
    QByteArray ea1 = ea.toLocal8Bit();
    std::string ea2= std::string(ea1);
    double ea3 =atof(ea2.c_str());
    QString bo = ui->bookvalue->text();
    QByteArray bo1 = bo.toLocal8Bit();
    std::string bo2= std::string(bo1);
    double bo3 =atof(bo2.c_str());

    QString a = ui->pe1->text();
    QByteArray a1 = a.toLocal8Bit();
    std::string a2= std::string(a1);
    double a3 =atof(a2.c_str());
    QString b = ui->pe2->text();
    QByteArray b1 = b.toLocal8Bit();
    std::string b2= std::string(b1);
    double b3 =atof(b2.c_str());
    QString c = ui->pe3->text();
    QByteArray c1 = c.toLocal8Bit();
    std::string c2= std::string(c1);
    double c3 =atof(c2.c_str());
    double sum1 = a3+b3+c3;
    double ave1 = sum1/3;

    QString d = ui->pb1->text();
    QByteArray d1 = d.toLocal8Bit();
    std::string d2= std::string(d1);
    double d3 =atof(d2.c_str());
    QString e = ui->pb2->text();
    QByteArray e1 = e.toLocal8Bit();
    std::string e2= std::string(e1);
    double e3 =atof(e2.c_str());
    QString f = ui->pb3->text();
    QByteArray f1 = f.toLocal8Bit();
    std::string f2= std::string(f1);
    double f3 =atof(f2.c_str());
    double sum2 = d3+e3+f3;
    double ave2 = sum2/3;

    QString h = ui->ps1->text();
    QByteArray h1 = d.toLocal8Bit();
    std::string h2= std::string(h1);
    double h3 =atof(h2.c_str());
    QString j = ui->ps2->text();
    QByteArray j1 = e.toLocal8Bit();
    std::string j2= std::string(j1);
    double j3 =atof(j2.c_str());
    QString k = ui->ps3->text();
    QByteArray k1 = k.toLocal8Bit();
    std::string k2= std::string(k1);
    double k3 =atof(k2.c_str());
    double sum3 = h3+j3+k3;
    double ave3 = sum3/3;

    double result =(ave1*sa3 +ave2*ea3+ ave3*bo3)/3;


    QString Answer="answer:";
    QString answer=QString::number(result);
    Answer = Answer+answer;
    QMessageBox::information(NULL, "Title", Answer, QMessageBox::Ok);


}
