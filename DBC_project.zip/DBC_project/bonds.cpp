#include "bonds.h"
#include "ui_bonds.h"

bonds::bonds(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::bonds)
{
    ui->setupUi(this);
}

bonds::~bonds()
{
    delete ui;
}

void bonds::on_pushButton_clicked()
{
   bo1.show();
}

void bonds::on_pushButton_2_clicked()
{
   bo2.show();
}
