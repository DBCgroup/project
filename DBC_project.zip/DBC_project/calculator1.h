#ifndef CALCULATOR1_H
#define CALCULATOR1_H

#include <QDialog>
#include <calculatorstandard.h>

namespace Ui {
class calculator1;
}

class calculator1 : public QDialog
{
    Q_OBJECT

public:
    explicit calculator1(QWidget *parent = nullptr);
    ~calculator1();

private slots:
    void on_pushButton_clicked();

private:
    Ui::calculator1 *ui;
    CalculatorStandard calculator;
};

#endif // CALCULATOR1_H
