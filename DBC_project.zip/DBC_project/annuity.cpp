#include "annuity.h"
#include "ui_annuity.h"

annuity::annuity(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::annuity)
{
    ui->setupUi(this);
}

annuity::~annuity()
{
    delete ui;
}

void annuity::on_pushButton_clicked()
{
    ann1.show();
}

void annuity::on_pushButton_2_clicked()
{
    ann2.show();
}

void annuity::on_pushButton_3_clicked()
{
    ann3.show();
}

void annuity::on_pushButton_4_clicked()
{
    ann4.show();
}
