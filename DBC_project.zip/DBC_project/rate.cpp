#include "rate.h"
#include "ui_rate.h"

rate::rate(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::rate)
{
    ui->setupUi(this);
}

rate::~rate()
{
    delete ui;
}

void rate::on_pushButton_clicked()
{
    r1.show();
}

void rate::on_pushButton_2_clicked()
{
    r2.show();
}
