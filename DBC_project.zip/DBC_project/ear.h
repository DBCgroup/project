#ifndef EAR_H
#define EAR_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class ear;
}

class ear : public QDialog
{
    Q_OBJECT

public:
    explicit ear(QWidget *parent = nullptr);
    ~ear();

private slots:
    void on_pushButton_clicked();

private:
    Ui::ear *ui;

};

#endif // EAR_H
