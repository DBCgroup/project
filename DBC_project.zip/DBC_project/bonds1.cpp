#include "bonds1.h"
#include "ui_bonds1.h"

bonds1::bonds1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::bonds1)
{
    ui->setupUi(this);
}

bonds1::~bonds1()
{
    delete ui;
}

void bonds1::on_pushButton_clicked()
{
    QString p = ui->parvalue->text();
    QByteArray p1 = p.toLocal8Bit();
    std::string p2= std::string(p1);
    double p3 =atof(p2.c_str());
    QString r = ui->r->text();
    QByteArray r1 = r.toLocal8Bit();
    std::string r2= std::string(r1);
    double r3 =atof(r2.c_str());
    QString t = ui->t->text();
    QByteArray t1 = t.toLocal8Bit();
    std::string t2= std::string(t1);
    int t3 =atoi(t2.c_str());

    double a=1+r3;

    for(int i=1; i<t3; i++)
    {
        a=a*(1+r3);
    }

    double result1= p3/a;

    QString Answer="answer:";
    QString answer=QString::number(result1);
    Answer = Answer+answer;
    QMessageBox::information(NULL, "Title", Answer, QMessageBox::Ok);
}
