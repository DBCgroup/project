#ifndef RATE2_H
#define RATE2_H

#include <QDialog>
#include <QMessageBox>

namespace Ui {
class rate2;
}

class rate2 : public QDialog
{
    Q_OBJECT

public:
    explicit rate2(QWidget *parent = nullptr);
    ~rate2();

private slots:
    void on_pushButton_clicked();

private:
    Ui::rate2 *ui;
};

#endif // RATE2_H
